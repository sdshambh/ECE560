#ifndef MISC_H
#define MISC_H

#define MASK(x) (1UL << (x))

#endif // MISC_H
